var totalchoices=1;
var locationlist = "";
var stepid=1;
var lastcompleted=1;
//Actions

function buildreviewpage()
{
	$('#review_name').text($("input[name='fullname']").val());
	$('#review_gender').text($("#gender").find("option:selected").text());
	$('#review_term').text($("#termid").find("option:selected").text());
	$('#review_birthdate').text($("input[name='birthdate']").val());
	$('#review_email').text($("input[name='personalemail']").val());
	$('#review_lastsemester').text($("input[name='stayedLastSemester']").val());
	$('#review_international_student').text($("input[name='internationalstudent']").val());
	$('#review_gender').text($("input[name='gender']").val());	
	var graduationdate = $("#gradmonth").find("option:selected").text() + " " + $("#gradyear").find("option:selected").text();	
	$('#review_graduationdate').text(graduationdate);
	$('#review_emergency_contact_firstname').text($("input[name='emergencycontactfirst']").val());
	$('#review_emergency_contact_lastname').text($("input[name='emergencycontactlast']").val());
	$('#review_emergency_contact_email').text($("input[name='emergencycontactemail']").val());	
	$('#review_emergency_contact_phone').text($("input[name='emergencycontacttelephone']").val());
	$('#review_international_country').text($("#contactcountry").find("option:selected").text());	
}

function updateDisplay() {
    var isChecked = $checkbox.is(':checked');
    $button.prepend('<i class="icon-chec"></i>');
    
    // Set the button's state
    $button.data('state', (isChecked) ? "on" : "off");

    // Set the button's icon
    $button.find('.state-icon')
        .removeClass()
        .addClass('state-icon ' + settings[$button.data('state')].icon);

    // Update the button's color
    if (isChecked) {
        $button
            .removeClass('btn-default')
            .addClass('btn-' + color + ' active');
    }
    else {
        $button
            .removeClass('btn-' + color + ' active')
            .addClass('btn-default');
    }
}

function gotoStep(displaystep)
{
	if(lastcompleted >= displaystep)
	{
	    $('#step' + displaystep).show();
	    $('#step' + stepid).hide();
		$('#step' + stepid + 'h').removeClass('active');                                  
	    $('#step' + displaystep + 'h').addClass('active');   
	    stepid=displaystep;
	}
	
	if(displaystep>=5) $("table.tblcontainer").css("width","80%");
    else $("table.tblcontainer").css("width","350px");
}

function removeitem(item){	
	$('#'+item).remove();
	$('input[type="hidden"][value="'+item+'"]').remove();
	$('input[type="hidden"][value="'+item+'"]').remove();			   
	totalchoices--;
	$('#locationterm' + totalchoices).empty();
	locationlist.replace(item + ';', '');
}

function toggleselect(btn){
	alert('test');
	btn.removeClass('btn btn-default');
	btn.addClass('btn btn-success');
	
}



function phonemask(f){
	
    tel='(';
    var val =f.value.split('');
    for(var i=0; i<val.length; i++){
    if( val[i]=='(' ){ 
    val[i]=''
    }
    if( val[i]==')' ){ 
    val[i]=''
    }
    if( val[i]=='-' ){ 
    val[i]=''
    }
    if( val[i]=='' ){ 
    val[i]=''
    }
    }
    //
    for(var i=0; i<val.length; i++){
        if(i==3){ val[i]=val[i]+')' }
        if(i==7){ val[i]=val[i]+'-' }
        if(i==12){ val[i]=val[i]+'' }   
        $('phone').keypress(function(event) 
        { 
           alert(event.keyCode); 
        });
    
    if(f.keyCode == 8) alert('backspace trapped');
    
        tel=tel+val[i]
    }
    f.value=tel;
}


function carnextstep() {
	
	$('#step' + stepid).hide();
	$('#step' + stepid + 'h').addClass('disabled');
	
    stepid--;                           
    $('#step' + stepid).show();        
    
    if(stepid==1)
    {
        if($('#termid').val()==2) $('#step1b').show();
        else $('#step1b').hide();          
    }
    else $('#step1b').hide();
    
    if(stepid>=5) $("table.tblcontainer").css("width","80%");
    else $("table.tblcontainer").css("width","350px");
}

function carlaststep() {
	
	$('#step' + stepid).hide();
	//$('#step' + stepid + 'h').removeClass('current');
	$('#step' + stepid + 'hb').removeClass('badge-primary');
	$('#step' + stepid + 'hb').addClass('badge-success');
    stepid++;                  
    $('#step' + stepid).show();
    //$('#step' + stepid + 'h').addClass('current');
    $('#step' + stepid + 'hb').removeClass('badge-primary');
    $('#step' + stepid + 'hb').addClass('badge-primary');
    if(stepid==1)
    {
        if($('#termid').val()==2) $('#step1b').show();
        else $('#step1b').hide();          
    }
    else $('#step1b').hide();
    
    if(stepid>=5) $("table.tblcontainer").css("width","80%");
    else $("table.tblcontainer").css("width","350px");

    if(stepid==10) {
        $('#forwardbtn').attr("disabled", "disabled");
        $('#submitform').show();        
    }    
    else {
        $('#forwardbtn').removeAttr("disabled");
        $('#backbtn').removeAttr("disabled");
    }
	if(stepid==5) $('#additionalquestionsinstructions').slideDown(250);
	if(stepid==7) $('#locationinstructions').slideDown(250);    	
}

(function(d, s, id) {
	  var js, fjs = d.getElementsByTagName(s)[0];
	  if (d.getElementById(id)) return;
	  js = d.createElement(s); js.id = id;
	  js.src = "//connect.facebook.net/en_US/all.js#xfbml=1";
	  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));



$(document).ready(function(){
        
    var element = this;
    
    var buildingprefs="";
	buildreviewpage();
    $('#forwardbtn').attr("disabled", "disabled");
    $('#submitform').hide();
    $('#forwardbtn').show();

    
    $("[rel='tooltip']").tooltip();    
    $("[rel='popover']").popover({
    	placement : 'top', // top, bottom, left or right
    	title : 'This is my Title', 
    	html: 'true', 
    	content : '<div id="popOverBox">Your Text Here</div>'
     });
        
	$("#buildingselector").hide();
	$("#floorselector").hide();	
	$("#choicescontainer").hide();		

	//$('.btn.danger').button('toggle').addClass('fat')
	
	$('#btn16').on("click", function(e) {		
		$('#btn16').removeClass('btn btn-default');
		$('#btn16').addClass('btn btn-success');		
	})
	
	 $("#forwardbtn").on("click", function(e) {
		
    	if(validate(stepid)) {
        	$('#step' + stepid).hide();
        	$('#step' + stepid + 'h').removeClass('active');        	
            stepid++;                  
            $('#step' + stepid).show();
            $('#step' + stepid + 'h').addClass('active');
            $('#step' + stepid + 'h').removeClass('disabled');
            if(stepid==1)
            {
                if($('#termid').val()==2) $('#step1b').show();
                else $('#step1b').hide();          
            }
            else $('#step1b').hide();
            
            if(stepid>=5) $("table.tblcontainer").css("width","80%");
            else $("table.tblcontainer").css("width","350px");
        
            if(stepid==9) {
            	buildreviewpage();
                $('#forwardbtn').attr("disabled", "disabled");
                $('#submitform').show();
                $('#forwardbtn').hide();
                
            }    
            else {
                $('#forwardbtn').removeAttr("disabled");
                $('#backbtn').removeAttr("disabled");
            }
            if(stepid > lastcompleted) lastcompleted=stepid;
    	}        
    	if(stepid==5) $('#additionalquestionsinstructions').slideDown(250);
    	if(stepid==7) $('#locationinstructions').slideDown(250);    	
    	    	
    	
    	
    })

    $('#showlocationinstructions').click(function(){
    	$('#locationinstructions').slideDown(250);
    });
    
    $('#btnhidelocationinstructions').click(function(){
    	$('#locationinstructions').slideUp(250);
    });

    $('#btncloselocationinstructions').click(function(){
    	$('#locationinstructions').slideUp(250);
    });

    
    $('#btnshowpreferenceinstructions').click(function(){    	
    	$('#additionalquestionsinstructions').slideDown(250);
    });
    
    $('#btnhidepreferncesinstructions').click(function(){
    	$('#additionalquestionsinstructions').slideUp(250);
    });

    $('#btnclosepreferncesinstructions').click(function(){
    	$('#additionalquestionsinstructions').slideUp(250);
    });

	
    $("#btn_term_spring").click(function(e){    	
    	$("#btn_term_summer").removeClass('btn-success');    	
    	$("#btn_term_fall").removeClass('btn-success');    	    			
		$("#btn_term_spring").addClass('btn-success');
		$('#termid').val('1');
		$('#step1b').hide();
	})

    $("#btn_term_summer").click(function(e){    	
    	$("#btn_term_spring").removeClass('btn-success');    	
    	$("#btn_term_fall").removeClass('btn-success');    	    			
		$("#btn_term_summer").addClass('btn-success');
		$('#termid').val('2');
		$('#step1b').show();
	})

    $("#btn_term_fall").click(function(e){    	
    	$("#btn_term_spring").removeClass('btn-success');    	
    	$("#btn_term_summer").removeClass('btn-success');    	
    	$("#btn_term_fall").addClass('btn-success');
    	$('#termid').val('3');
    	$('#step1b').hide();
	})
	
    $("#btn_summer_term_1").click(function(e){    	        	
    	if($("#btn_summer_term_1").hasClass('btn-success')){
    		$("#btn_summer_term_1").removeClass('btn-success');    		
    		$("#btn_summer_term_1").removeClass('active');
    	}
    	else{
    		$("#btn_summer_term_1").addClass('btn-success');
    		$("#btn_summer_term_1").addClass('active');
    	}
	})
    
    $("#btn_summer_term_2").click(function(e){    	        	
    	if($("#btn_summer_term_2").hasClass('btn-success')){
    		$("#btn_summer_term_2").removeClass('btn-success');
    		$("#btn_summer_term_2").removeClass('active');
    	}
    	else{
    		$("#btn_summer_term_2").addClass('btn-success');
    		$("#btn_summer_term_2").addClass('active');
    	}
	})

    $("#btn_summer_term_3").click(function(e){       	
    	if($("#btn_summer_term_3").hasClass('btn-success')){
    		$("#btn_summer_term_3").removeClass('btn-success');
    		$("#btn_summer_term_3").removeClass('active');
    	}
    	else{
    		$("#btn_summer_term_3").addClass('btn-success');
    		$("#btn_summer_term_3").addClass('active');
    	}
	})
	
	$('#termid').change(function() {	
	    $('#mealplan').empty();
	    $('#mealplan').load('/Enrollment/housing/index/mealplan/' + $('#termid').val());	    
	})
		
    $("#mgenderbtn").click(function(e){    	
		$("#mgenderbtn").removeClass('btn-default');
		$("#mgenderbtn").addClass('btn-success');
		$("#fgenderbtn").removeClass('btn-success');
		$("#fgenderbtn").addClass('btn-default');
		$('#review_gender').text('Female');
	})

	$("#fgenderbtn").click(function(e){		
		$("#fgenderbtn").removeClass('btn-default');
		$("#fgenderbtn").addClass('btn-success');
		$("#mgenderbtn").removeClass('btn-success');
		$("#mgenderbtn").addClass('btn-default');
		$('#review_gender').text('Male');
	})

	
	$("#internatbtn").click(function(e){	
		$("#internatbtn").removeClass('btn-default');
		$("#internatbtn").addClass('btn-success');
		$("#noninternatbtn").removeClass('btn-success');
		$("#noninternatbtn").addClass('btn-default');
		$('#international')[0].checked = true;
		$('#step2b').show();
		$('#review_international_student').text('Yes');
		$('#internationalstudent').val('Yes');					
		$('#review_country_section').show();
	})

	$("#noninternatbtn").click(function(e){		
		$("#noninternatbtn").removeClass('btn-default');
		$("#noninternatbtn").addClass('btn-success');
		$("#internatbtn").removeClass('btn-success');
		$("#internatbtn").addClass('btn-default');
		$('#step2b').hide();
		$('#noninternational')[0].checked = true;		
		$('#review_international_student').text('No');
		$('#internationalstudent').val('No');
		$('#review_country_section').hide();
		
	})

	
	$(function() {
	    $('#termid').on('change', function(e) {
	        if($('#termid').val()==2) {
	         	$('#step1b').show();
	        }
	        else {
	        	$('#step1b').hide();
	        }
	    });
	});
	
	
	
	$("#phone").keydown(function(event) {
	    // Allow: backspace, delete, tab, escape, enter and .
	    if ( $.inArray(event.keyCode,[46,8,9,27,13,190]) !== -1 ||
	         // Allow: Ctrl+A
	        (event.keyCode == 65 && event.ctrlKey === true) || 
	         // Allow: home, end, left, right
	        (event.keyCode >= 35 && event.keyCode <= 39)) {
	             // let it happen, don't do anything
	             return;
	    }
	    else {
	        // Ensure that it is a number and stop the keypress
	        if (event.shiftKey || (event.keyCode < 48 || event.keyCode > 57) && (event.keyCode < 96 || event.keyCode > 105 )) {
	            event.preventDefault(); 
	        }   
	    }
	});
	
	
	$(function () {
		
/*	    if(stepid==5) $("table.tblcontainer").css("width","80%");
	    else if(stepid==6) { $("table.tblcontainer").css("width","350px"); }
	    else if(stepid>=7) $("table.tblcontainer").css("width","80%");
	    else $("table.tblcontainer").css("width","350px");
*/
		
		if(stepid>=5) $("table.tblcontainer").css("width","80%");
	    else $("table.tblcontainer").css("width","350px");

	    $("#noninternatbtn").removeClass('btn-default');
		$("#noninternatbtn").addClass('btn-success');
		$("#noninternatbtn").addClass('active');

		
	    $('.button-checkbox').each(function () {

	        // Settings
	        var $widget = $(this),
	            $button = $widget.find('button'),
	            $checkbox = $widget.find('input:checkbox'),
	            color = $button.data('color'),
	            settings = {
	                on: {
	                    icon: 'icon icon-check'
	                },
	                off: {
	                    icon: ''
	                }
	            };

	        // Event Handlers
	        $button.on('click', function () {
	            $checkbox.prop('checked', !$checkbox.is(':checked'));
	            $checkbox.triggerHandler('change');
	            updateDisplay();
	        });
	        $checkbox.on('change', function () {
	            updateDisplay();
	        });

	        // Actions
	        function updateDisplay() {
	            var isChecked = $checkbox.is(':checked');

	            // Set the button's state
	            $button.data('class', (isChecked) ? "btn-default" : "btn-success");

	            // Set the button's icon
	            $button.find('.status')
	                .removeClass()
	                .addClass('status ' + settings[$button.data('status')].icon);

	            // Update the button's color
	            if (isChecked) {
	                $button
	                    .removeClass('btn-default')
	                    .addClass('btn-' + color + ' active');
	            }
	            else {
	                $button
	                    .removeClass('btn-' + color + ' active')
	                    .addClass('btn-default');
	            }
	        }

	        // Initialization
	        function init() {
	        	
	            updateDisplay();

	        }
	        init();
	    });
	});
	
})(jQuery);

