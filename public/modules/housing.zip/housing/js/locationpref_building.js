

var locationcount=1;
var prefs=new Array();

var buildingArr=new Object();
buildingArr[16]= 'Dayton Double';	    	
buildingArr[17]= 'Dayton Triple';	    	
buildingArr[21]= 'South Single';	    	
buildingArr[22]= 'South Double';	    	
buildingArr[18]= 'Dayton Double';	    	
buildingArr[19]= 'Tonopah Double';	    	
buildingArr[20]= 'Tonopah Triple';	    	
buildingArr[23]= 'Hughes Delux Single';	       	
buildingArr[24]= 'B Hall Delux Single';	        
buildingArr[25]= 'C Hall Single';	    	
buildingArr[26]= 'C Hall Double';	    	
buildingArr[27]= 'Faiman Single';	    	
buildingArr[28]= 'Faiman Double';	    	


var specfloorArr=new Object();
specfloorArr[0]= 'No Special Interest';
specfloorArr[2]= 'All Women Floor';
specfloorArr[4]= 'Study Intensive Floor';
specfloorArr[14]= 'Honors House';
specfloorArr[17]= 'Hotel House';
specfloorArr[20]= 'Global House';
specfloorArr[23]= 'Graduate & Older';
specfloorArr[24]= 'Major Exploration';
specfloorArr[25]= 'Business House';

function showmsg(msg)
{
  $('#errormsg').html('<b>'+msg+'<b>');
  $('#errormsg').delay(2000).show();		  
  $('#errormsg').fadeOut('slow').delay(2000).hide(0);
}

function togglestyle(el){
    if(el.className == "on") {
    	el.className="off";
    } else {
    	el.className="on";
    }
}

function clearall()
{
	$('#groupdescription0').hide();
	$('#groupdescription1').hide();
	$('#groupdescription2').hide();
	$('#groupdescription3').hide();
	$('#groupdescription4').hide();
	$('#groupdescription5').hide();
	
}

function addspecfloor(id, label)
{
	if(locationcount>3) alert('You Have Select 3 Choices')
	else {
		$('#btnspecflooryes'+id).removeClass('btn-default');
		$('#btnspecflooryes'+id).addClass('btn-success');
		divtxt = "<div class=\"locchoice\" id=\"divlocationselection" + id + "\" > </div>";
		$('#specialtyfloorsections').append(divtxt);
		//inputhtml = "<input type=\"hidden\" name=\"location_" + id + "\" value=\"" + id + "\"> ";
		inputhtml = "<input type=\"hidden\" name=\"location_" + id + "\" value=\"" + id + "\"> <span class=\"badge\">" + label +  "<a href=\"#\">X</a> </span>";
		$('#locationpreference_'+locationcount).append(divtxt);
		
		prefs.push(specfloorArr[id]);
		$('#divlocationselection'+id).html(inputhtml);                          
		$('#divspecialtyterm_'+id).show();
				
		var reviewlocationtext = '<div id=\"review_location_' + id + '\">' + 'Preference ' + locationcount + '<br>Specialty Floor: ' + label + '</div><br><br>';
		$("#review_location_preference").append(reviewlocationtext);
		
	    locationcount++;
	}
}    

function displayorderedlist()
{
	for(i=1;i<=3;i++)
	{
		locationlist[locationcount];	
	}
}


function addtoprefs(divtextstart, divtextend, inputhtml, id)
{
	
    prefs.push(divtxtstart + inputhtml + divtxtend);			
	$.each(prefs, function(key, value) { 
		$('#specialtyfloorsections').append(key + ') ' + value);
	});		
}

function addlocroom123(id)
{
	if(locationcount>3) alert('You Have Select 3 Choices')
	else {
		divtxt = "<div class=\"\" id=\"divlocationselection" + id + "\" align=\"left\"></div";		
		$('#specialtyfloorsections').append(divtxt);																													                           
		
		inputhtml = "<input type=\"hidden\" name=\"location_" + id + "\" id=\"location_" + id + "\" value=\"" + id + "\"> <h6>" + label +  "&nbsp;&nbsp; <span class=\"badge\"><a href=\"#\" onclick=\"removelocroom(" + id + ");\">remove</a> </span></h6>";
		$('#divlocationselection'+id).html(inputhtml);				
		prefs.push(buildingArr[id]);		
		//addtoprefs(divtxtstart, divtxtend, inputhtml, id);
		$("#floorplan_img_"+id).removeClass("img-unselected");
		$("#floorplan_img_"+id).addClass("img-selected");
		$("#floorplan_flag_"+id).show();
		$("#building_thumbnail_"+id).css('border-color', 'green');
		$("#building_thumbnail_"+id).css('border-width', 'thin');	
    	$('#building_title_'+id).removeClass('muted');
    	$('#building_price_'+id).removeClass('muted');
    	$('#floorplan_status_'+id).show();
    	
	
	    locationcount++;
	}
}

function addlocroom(id, label)
{
	if(locationcount>3) alert('You Have Select 3 Choices')
	else {
		divtxt = "<div class=\"locchoice\" id=\"divlocationselection" + id + "\" align=\"left\"><\div>";
		$('#specialtyfloorsections').append(divtxt);																													                           
		inputhtml = "<h6><input type=\"hidden\" name=\"priority_" + id + "\" id=\"location_" + id + "\" value=\"" + id + "\"> " + label +  "&nbsp;&nbsp; <span class=\"badge\"><a href=\"#\" onclick=\"removelocroom(" + id + ");\">remove</a> </span></h6>";
		$('#divlocationselection'+id).html(inputhtml);
		
		prefs.push(buildingArr[id]);
		showallprefs();
		
		//addtoprefs(divtxtstart, divtxtend, inputhtml, id);
		$("#floorplan_img_"+id).removeClass( "img-unselected");
		$("#floorplan_img_"+id).addClass( "img-selected");
		$("#floorplan_flag_"+id).show();
		$("#building_thumbnail_"+id).css('border-color', 'green');
		$("#building_thumbnail_"+id).css('border-width', 'thin');	
    	$('#building_title_'+id).removeClass('muted');
    	$('#building_price_'+id).removeClass('muted');
    	$('#floorplan_status_'+id).show();
    	
	
	    locationcount++;
	}
}


function showallprefs()
{
	$('#review_location_preference').html('');	
	$.each(prefs, function(key, value) {
	   $('#review_location_preference').append('<span><b>Preference ' + key + '. ' + value + '</span>');
	});
}



function removeFromArray(id) {		
    for (var i = 0; i < prefs.length; ) {
        if (prefs[i] == buildingArr[id]) {        	
        	prefs.splice(i, 1);            
        } else {
        	//alert(prefs[i]);
           ++i;
        }	  
	}		   
}

function removelocroom(id)
{
	
	locationcount--;
    $("#divlocationselection"+id).remove();
	$("#floorplan_img_"+id).removeClass( "img-selected");
	$("#floorplan_img_"+id).addClass( "img-unselected");
//	$("#review_location_"+id).remove();
	$("#building_thumbnail_"+id).css('border-color', 'lightgray');
	$("#building_thumbnail_"+id).css('border-width', 'thin');
	$('#building_title_'+id).addClass('muted');
	$('#building_price_'+id).addClass('muted');
	$('#floorplan_status_'+id).hide();		   
    removeFromArray(id);
    
	$('#review_location_preference').html('');	
	$.each(prefs, function(key, value) {
	   $('#review_location_preference').append('<span><b>Preference ' + key + '. ' + value + '</span>');
	});
	//showallprefs();
	
}



function removespecfloor(id)
{
	locationcount--;
	$('#btnspecflooryes'+id).removeClass('btn-success');
	$('#btnspecflooryes'+id).addClass('btn-default');    
    $('#divlocationselection'+id).remove();
    $('#divspecialtyterm_'+id).hide();
    $('#review_location_'+id).remove();
}

function dspfloorgrp(id)
{	
	$('#floor_group_1').slideUp(250);
	$('#list_item_1').removeClass('active');
	$('#floor_group_2').slideUp(250);
	$('#list_item_2').removeClass('active');
	$('#floor_group_3').slideUp(250);
	$('#list_item_3').removeClass('active');	
	$('#list_item_'+id).addClass('active');
	$('#floor_group_'+id).slideDown(250);	
}

function dspUCCgrp(id)
{	
	$('#ucc_group_1').slideUp(250);
	$('#ucc_list_item_1').removeClass('active');
	$('#ucc_group_2').slideUp(250);
	$('#ucc_list_item_2').removeClass('active');
	$('#ucc_list_item_'+id).addClass('active');
	$('#ucc_group_'+id).slideDown(250);	
}

$(document).ready(function(){
  
    var buildingprefs="";
    var index=0;
    
    $("a[href='#']").click(function(e) {
        e.preventDefault();
    });
    
    
    $('#btnshowlist').click(function(){
    	$('#specialtyfloorsections').html('');
    	
    	$.each(prefs, function(key, value) {
    	   $('#specialtyfloorsections').append('<span><b>Preference '+key + '. ' + value + '</span>');
    	});
    });

    
    
    function initimages()
    {
    	$( "#daytonfloorplans" ).hide();
    	$( "#tonopahfloorplans" ).hide();
    	$( "#southfloorplans" ).hide();
    	$( "#uccfloorplans" ).hide();
    	
    	$( "#dayton_thumbnail").css('border-color', 'lightgray');    
    	$( "#tonopah_thumbnail").css('border-color', 'lightgray');    
    	$( "#south_thumbnail").css('border-color', 'lightgray');    
    	$( "#ucc_thumbnail").css('border-color', 'lightgray');    

    	$( "#daytonimage" ).removeClass( "img-selected");
    	$( "#daytonimage" ).addClass( "img-unselected");

    	$( "#tonopahimage" ).removeClass( "img-selected");
    	$( "#tonopahimage" ).addClass( "img-unselected");

    	$( "#southimage" ).removeClass( "img-selected");
    	$( "#southimage" ).addClass( "img-unselected");

    	$( "#uccimage" ).removeClass( "img-selected");
    	$( "#uccimage" ).addClass( "img-unselected");

    	$( "#dayton_title" ).addClass('muted');
    	$( "#south_title" ).addClass('muted');
    	$( "#tonopah_title" ).addClass('muted');
    	$( "#ucc_title" ).addClass('muted');

    	$( "#daytonimagebutton" ).removeClass( "active");    	    	    
    	$( "#southimagebutton" ).removeClass( "active");    	
    	$( "#tonopahimagebutton" ).removeClass( "active");    	
    	$( "#uccimagebutton" ).removeClass( "active");
    	
    }

    $(function () {
        $('.btn-radio').click(function(e) {
            $('.btn-radio').not(this).removeClass('active')
        		.siblings('input').prop('checked',false)
                .siblings('.img-radio').css('opacity','0.5');
        	$(this).addClass('active')
                .siblings('input').prop('checked',true)
        		.siblings('.img-radio').css('opacity','1');
        });        
    });
    
    $('#daytonimagebutton').click(function(){
    	initimages();    	
    	$( "#daytonimagebutton" ).show();
    	$( "#dayton_title" ).removeClass('muted');
    	$( "#daytonimagebutton" ).addClass('active');
    	$( "#daytonimage" ).addClass( "img-selected");    	
    	$( "#daytonfloorplans" ).slideDown(250);    	    
    	$( "#dayton_thumbnail").css('border-color', 'blue');
    	$( "#btnplansdayton" ).removeClass( "btn-default");
    	$( "#btnplansdayton" ).addClass( "btn-success");    	    	
    });

    $('#southimagebutton').click(function(){
    	initimages();
    	$( "#southimagebutton").show();    	
    	$( "#south_title" ).removeClass('muted');
    	$( "#southimagebutton" ).addClass('active');
    	$( "#southimage" ).removeClass( "img-unselected");
    	$( "#southimage" ).addClass( "img-selected");
    	$( "#southfloorplans" ).slideDown(250);
    	$( "#south_thumbnail").css('border-color', 'blue');
    	$( "#btnplanscomplex" ).removeClass( "btn-default");
    	$( "#btnplanscomplex" ).addClass( "btn-success");    	
    });


    $('#tonopahimagebutton').click(function(){
    	initimages();
    	$( "#tonopahimagebutton" ).addClass('active');
    	$( "#tonopah_title" ).removeClass('muted');

    	$( "#tonopahimage" ).removeClass( "img-unselected");
    	$( "#tonopahimage" ).addClass( "img-selected");
    	$( "#tonopahfloorplans" ).slideDown(250);
    	$( "#tonopah_thumbnail").css('border-color', 'blue');
    	$( "#btnplantonopah" ).removeClass( "btn-default");
    	$( "#btnplantonopah" ).addClass( "btn-success");    	
    });
    

    $('#uccimagebutton').click(function(){
    	initimages();
    	$( "#uccimagebutton" ).addClass('active');
    	$( "#ucc_title" ).removeClass('muted');
    	$( "#uccimage" ).removeClass( "img-unselected");
    	$( "#uccimage" ).addClass( "img-selected");
    	$( "#uccfloorplans" ).slideDown(250);
    	$( "#ucc_title" ).removeClass('bldginfonoselect');
    	$( "#ucc_title" ).addClass('bldginfoselect');    	    
    	$( "#ucc_thumbnail").css('border-color', 'blue');
    	$( "#btnplanucc" ).removeClass( "btn-default");
    	$( "#btnplanucc" ).addClass( "btn-success");    	
    });
    

    
    
    $('#dayton_double').click(function(){
    	
    	if($('#location_16').length) removelocroom(16);    	    	
    	else addlocroom(16, 'Dayton Double');	    	
    });

    $('#dayton_triple').click(function(){
    	if($('#location_17').length) removelocroom(17);    	    	
    	else addlocroom(17, 'Dayton Triple');	    	
    });
    
    $('#south_single').click(function(){
    	if($('#location_21').length) removelocroom(21);    	    	
    	else addlocroom(21, 'South Single');	    	
    });

    $('#south_double').click(function(){
    	if($('#location_22').length) removelocroom(22);    	    	
    	else addlocroom(22, 'South Double');	    	
    });    
    
    $('#tonopah_single').click(function(){
    	if($('#location_18').length) removelocroom(18);    	    	
    	else addlocroom(18, 'Dayton Double');	    	
    });

    $('#tonopah_double').click(function(){
    	if($('#location_19').length) removelocroom(19);    	    	
    	else addlocroom(19, 'Tonopah Double');	    	
    });

    $('#tonopah_triple').click(function(){
    	if($('#location_20').length) removelocroom(20);    	    	
    	else addlocroom(20, 'Tonopah Triple');	    	
    });

    $('#hughes_deluxe_single').click(function(){    	
    	if($('#location_23').length) removelocroom(23);
    	else addlocroom(23, 'Hughes Delux Single');	       	
    });
        
    $('#b_hall_single').click(function(){    	    	
    	if($('#location_24').length) removelocroom(24);
    	else addlocroom(24, 'B Hall Delux Single');	        
    });

    $('#c_hall_single').click(function(){
    	if($('#location_25').length) removelocroom(25);
    	else addlocroom(25, 'C Hall Single');	    	
    });

    $('#c_hall_double').click(function(){
    	if($('#location_26').length) removelocroom(26);    	    	
    	else addlocroom(26, 'C Hall Double');	    	
    });
    
    $('#faiman_single').click(function(){
    	if($('#location_27').length) removelocroom(27);    	    	
    	else addlocroom(27, 'Faiman Single');	    	
    });
    
    $('#faiman_double').click(function(){
    	if($('#location_28').length) removelocroom(28);    	    	
    	else addlocroom(28, 'Faiman Double');	    	
    });
    
    
    
    
    //Specialty Floors
    
    
    $('#panel_2').hover(function(){
    	alert('test');
    	$('#info_specialty_panel_2').show();
    });
    
    function selectfloortile(id)
    {
    	if(locationcount>3) {
    	    window.scrollTo(0,0);	
    		showmsg('You have already chosen 3 options.  Please click on the selected button to remove a selection.');
    	}
    	else{
	    	$('#title_'+id).removeClass('muted');
	    	$('#desc_short_'+id).removeClass('muted');
	    	$('#desc_long_'+id).removeClass('muted');
	    	$('#floor_loc_badge_'+id).removeClass('badge-default');
	    	$('#floor_loc_badge_'+id).addClass('badge-info');

	    	$('#btnspecfloorselect_'+id).removeClass('btn-default');
	    	$('#btnspecfloorselect_'+id).addClass('btn-success');    	  
	    	$('#btnspecfloorselect_'+id).text('Selected');
	    	$('#btnspecfloorselect_'+id).addClass('active');
    	}
    }

    function deselectfloortile(id)
    {
    	$('#title_'+id).addClass('muted');
    	$('#desc_short_'+id).addClass('muted');
    	$('#desc_long_'+id).addClass('muted');
    	$('#floor_loc_badge_'+id).removeClass('badge-info');
    	$('#floor_loc_badge_'+id).addClass('badge-default');

    	$('#building_title_'+id).addClass('muted');
    	$('#building_price_'+id).addClass('muted');

    	$('#btnspecfloorselect_'+id).removeClass('btn-success');
    	$('#btnspecfloorselect_'+id).addClass('btn-default');
    	$('#btnspecfloorselect_'+id).removeClass('active');
    	$('#btnspecfloorselect_'+id).text('Choose');
    }

    
    $('#btnspecfloorselect_0').click(function(){    	    	
       if($('#btnspecfloorselect_0').text()=='Choose') {
    	   selectfloortile(0);
    	   addspecfloor(0, 'No Special Interest');
       }
       else {
    	   deselectfloortile(0);
    	   removespecfloor(0);
       }
    });

    
    $('#btnspecfloorselect_2').click(function(){    	    	
        if($('#btnspecfloorselect_2').text()=='Choose'){
     	   selectfloortile(2);
     	   addspecfloor(2, 'All Women Floor');
        }
        else {
     	   deselectfloortile(2);
     	   removespecfloor(2);
        }
     });

    
    $('#btnspecfloorselect_4').click(function(){    	    	
        if($('#btnspecfloorselect_4').text()=='Choose'){
     	   selectfloortile(4);
     	   addspecfloor(4, 'Study Intensive Floor');
        }
        else {
     	   deselectfloortile(4);
     	   removespecfloor(4);
        }
     });

    
    $('#btnspecfloorselect_14').click(function(){    	    	
        if($('#btnspecfloorselect_14').text()=='Choose'){
     	   selectfloortile(14);
     	   addspecfloor(14, 'Honors House');
        }
        else {
     	   deselectfloortile(14);
     	   removespecfloor(14);
        }
     });

    
    $('#btnspecfloorselect_17').click(function(){    	    	
        if($('#btnspecfloorselect_17').text()=='Choose'){
     	   selectfloortile(17);
     	   addspecfloor(17, 'Hotel House');
        }
        else {
     	   deselectfloortile(17);
     	   removespecfloor(17);
        }
     });

    
    $('#btnspecfloorselect_20').click(function(){    	    	
        if($('#btnspecfloorselect_20').text()=='Choose'){
     	   selectfloortile(20);
     	   addspecfloor(20, 'Global House');
        }
        else {
     	   deselectfloortile(20);
     	   removespecfloor(20);
        }
     });

    
    $('#btnspecfloorselect_23').click(function(){    	    	
        if($('#btnspecfloorselect_23').text()=='Choose'){
     	   selectfloortile(23);
     	   addspecfloor(23, 'Graduate & Older');
        }
        else {
     	   deselectfloortile(23);
     	   removespecfloor(23);
        }
     });

    $('#btnspecfloorselect_24').click(function(){    	    	
        if($('#btnspecfloorselect_24').text()=='Choose'){
     	   selectfloortile(24);
     	   addspecfloor(24, 'Major Exploration');
        }
        else {
     	   deselectfloortile(24);
     	   removespecfloor(24);
        }
     });

    
    
    $('#btnspecfloorselect_25').click(function(){    	    	
        if($('#btnspecfloorselect_25').text()=='Choose'){
     	   selectfloortile(25);
     	   addspecfloor(25, 'Business House');
        }
        else {
     	   deselectfloortile(25);
     	   removespecfloor(25);
        }
     });
    
    
    $('#floor_desc_more_text_0').click(function(){    	    	
    	$('#desc_top_short_0').hide();
    	$('#desc_top_long_0').show();
    })

    $('#floor_desc_less_text_0').click(function(){    	    	
    	$('#desc_top_long_0').hide();
    	$('#desc_top_short_0').show();
    })

    $('#floor_desc_more_text_2').click(function(){    	    	
    	$('#desc_top_short_2').hide();
    	$('#desc_top_long_2').show();
    })

    $('#floor_desc_less_text_2').click(function(){    	    	
    	$('#desc_top_long_2').hide();
    	$('#desc_top_short_2').show();
    })

    $('#floor_desc_more_text_4').click(function(){    	    	
    	$('#desc_top_short_4').hide();
    	$('#desc_top_long_4').show();
    })

    $('#floor_desc_less_text_4').click(function(){    	    	
    	$('#desc_top_long_4').hide();
    	$('#desc_top_short_4').show();
    })

    $('#floor_desc_more_text_14').click(function(){    	    	
    	$('#desc_top_short_14').hide();
    	$('#desc_top_long_14').show();
    })

    $('#floor_desc_less_text_14').click(function(){    	    	
    	$('#desc_top_long_14').hide();
    	$('#desc_top_short_14').show();
    })

    $('#floor_desc_more_text_17').click(function(){    	    	
    	$('#desc_top_short_17').hide();
    	$('#desc_top_long_17').show();
    })

    $('#floor_desc_less_text_17').click(function(){    	    	
    	$('#desc_top_long_17').hide();
    	$('#desc_top_short_17').show();
    })

    $('#floor_desc_more_text_20').click(function(){    	    	
    	$('#desc_top_short_20').hide();
    	$('#desc_top_long_20').show();
    })

    $('#floor_desc_less_text_20').click(function(){    	    	
    	$('#desc_top_long_20').hide();
    	$('#desc_top_short_20').show();
    })

    
    $('#floor_desc_more_text_23').click(function(){    	    	
    	$('#desc_top_short_23').hide();
    	$('#desc_top_long_23').show();
    })

    $('#floor_desc_less_text_23').click(function(){    	    	
    	$('#desc_top_long_23').hide();
    	$('#desc_top_short_23').show();
    })

    
    
    $('#floor_desc_more_text_24').click(function(){    	    	
    	$('#desc_top_short_24').hide();
    	$('#desc_top_long_24').show();
    })

    $('#floor_desc_less_text_24').click(function(){    	    	
    	$('#desc_top_long_24').hide();
    	$('#desc_top_short_24').show();
    })

    
    
    $('#floor_desc_more_text_25').click(function(){    	    	
    	$('#desc_top_short_25').hide();
    	$('#desc_top_long_25').show();
    })

    $('#floor_desc_less_text_25').click(function(){    	    	
    	$('#desc_top_long_25').hide();
    	$('#desc_top_short_25').show();
    })
    

	$("#byfloors").click(function(e){		
		locationcount=1;
		$('#specialtyfloorsections').html('');
		$("#building").hide();
		$("#floor").show();	
		$("#byfloorsicon").addClass( "icon-check" );
		$("#bybuildingsicon").removeClass( "icon-check" );
		$("#byfloors").removeClass('btn-default');
		$("#byfloors").addClass('btn-info active');
		$("#bybuildings").removeClass('btn-info active');
		$("#bybuildings").addClass('btn-default');
		$("#byfloor").prop("checked", true);
		$('#collapseOne').collapse();
	});
	
	$("#bybuildings").click(function(e){
		locationcount=1;
		$('#specialtyfloorsections').html('');
		$("#building").show();
		$("#floor").hide();
		$("#bybuildingsicon").addClass( "icon-check" );
		$("#byfloorsicon").removeClass( "icon-check" );
		$("#bybuildings").removeClass('btn-default');
		$("#bybuildings").addClass('btn-info active');
		$("#byfloors").removeClass('btn-info active');
		$("#byfloors").addClass('btn-default');
		$("#bybuilding").prop("checked", true);
		$('#collapseOne').collapse();
	});

   
    
    $('div.accordion-body').on('shown', function () {
        $(this).parent("div").find(".icon-chevron-down")
               .removeClass("icon-chevron-down").addClass("icon-chevron-up");
    });

    $('div.accordion-body').on('hidden', function () {
        $(this).parent("div").find(".icon-chevron-up")
               .removeClass("icon-chevron-up").addClass("icon-chevron-down");
    });

    
    
})(jQuery);

